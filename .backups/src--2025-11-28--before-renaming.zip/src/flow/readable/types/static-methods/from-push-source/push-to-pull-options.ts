export interface PushToPullOptions {
  readonly dataRetentionTime?: number;
}

import { type ReadableFlowMapArgumentsFunction } from '../readable-flow-map-arguments-function.js';

/**
 * Used to set the arguments of a ReadableFlow.
 *
 * @param args - The arguments to set.
 * @returns {ReadableFlowMapArgumentsFunction<[], GArguments>} - A function that maps no arguments to a list of predefined ones.
 *
 * @example
 *
 * ```ts
 * const reader = flow.mapArguments(setArguments(10)).open(signal);
 * ``
 */
export function setArguments<GArguments extends readonly unknown[]>(
  ...args: GArguments
): ReadableFlowMapArgumentsFunction<[], GArguments> {
  return (): GArguments => args;
}

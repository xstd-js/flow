export interface ReadableFlowMapArgumentsFunction<
  GNewArguments extends readonly unknown[],
  GArguments extends readonly unknown[],
> {
  (...args: GNewArguments): GArguments;
}

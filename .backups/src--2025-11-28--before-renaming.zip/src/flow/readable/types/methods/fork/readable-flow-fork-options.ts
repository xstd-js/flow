export interface ReadableFlowForkOptions {
  readonly maintainAlive?: number;
  // readonly dataRetentionTime?: number;
}

import { ReadableFlowIterator } from './readable-flow-iterator.js';

export interface ReadableFlowFactory<GValue> {
  (signal: AbortSignal): ReadableFlowIterator<GValue>;
}

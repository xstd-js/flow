export type ReadableFlowIterator<GValue> = Required<
  Pick<AsyncIterator<GValue, void, void>, 'next' | 'return' | 'throw'>
>;

import { isAsyncGeneratorFunction } from '@xstd/async-generator';
import { listen } from '@xstd/disposable';
import { tryAsyncFnc } from '../../../shared/enum/result/functions/try-async-fnc.js';
import { isResultOk } from '../../../shared/enum/result/ok/is-result-ok.js';
import type { Result } from '../../../shared/enum/result/result.js';
import { ReadableFlowFactory } from '../types/readable-flow-factory.js';
import { ReadableFlowIterator } from '../types/readable-flow-iterator.js';

export class FlowReader<GValue>
  implements AsyncIterableIterator<GValue, void, void>, AsyncDisposable
{
  static debugMode: boolean = true;

  readonly #signal: AbortSignal;
  readonly #iterator: ReadableFlowIterator<GValue>;
  #currentInvocation: number;
  #signalAbortEventListener: Disposable | undefined;
  #signalAbortedButFlowNotDoneTimer: any | undefined;

  constructor(factory: ReadableFlowFactory<GValue>, signal: AbortSignal) {
    if (!isAsyncGeneratorFunction(factory)) {
      throw new TypeError('The factory must be an AsyncGenerator function.');
    }

    this.#signal = signal;
    this.#iterator = factory(this.#signal);
    this.#currentInvocation = 0;
  }

  #startSignalAbortedButFlowNotDoneTimer(): void {
    this.#signalAbortedButFlowNotDoneTimer = setTimeout((): void => {
      console.warn(
        'The signal was aborted while the flow was not running. If this happens, it is expected that one of the following methods of the flow is called to end it: `next`, `throw`, or `return`.',
      );
    }, 100);
  }

  #endSignalAbortedButFlowNotDoneTimer(): void {
    if (this.#signalAbortedButFlowNotDoneTimer !== undefined) {
      clearTimeout(this.#signalAbortedButFlowNotDoneTimer);
      this.#signalAbortedButFlowNotDoneTimer = undefined;
    }
  }

  #clearSignalAbortEventListener(): void {
    if (this.#signalAbortEventListener !== undefined) {
      this.#signalAbortEventListener[Symbol.dispose]();
      this.#signalAbortEventListener = undefined;
    }
  }

  /* ASYNC ITERATOR */

  async #iterate(
    callback: () => Promise<IteratorResult<GValue, void>>,
  ): Promise<IteratorResult<GValue, void>> {
    this.#currentInvocation++;
    const currentInvocation: number = this.#currentInvocation;

    this.#clearSignalAbortEventListener();
    this.#endSignalAbortedButFlowNotDoneTimer();

    const result: Result<IteratorResult<GValue, void>, void> = await tryAsyncFnc(callback);

    if (isResultOk(result)) {
      // └> the iterator resolved

      if (this.#signal.aborted) {
        // └> the signal is aborted

        if (!result.value.done) {
          // └> the iterator is not done

          // => the iterator should have rejected

          if (FlowReader.debugMode) {
            console.warn(
              'The `AsyncIterator` returned an `IteratorResult` with `{ done: false }` while the `signal` of this flow is aborted. If this signal is aborted, the `AsyncIterator` is expected to either reject with `signal.reason` or resolve with an `IteratorResult` => `{ done: true }`.',
            );
          }
        }
      } else {
        // └> the signal is not aborted

        if (result.value.done) {
          // └> the iterator is done
          // => the flow ends with `{ done: true }`
        } else {
          // └> the iterator is not done

          if (this.#currentInvocation === currentInvocation) {
            // └> the current invocation is the last one

            // => we are about to return the result
            //    if the signal is aborted while the flow is not running, we must ensure that the user ends the flow by calling one of its methods: `next`, `throw` or `return`.

            // we start listening to the signal's abort event.
            this.#signalAbortEventListener = listen(this.#signal, 'abort', (): void => {
              // └> the signal is aborted
              this.#clearSignalAbortEventListener();
              // => the flow is not ended yet
              // we start a timer to warn the user if the flow is not ended in a reasonable amount of time
              this.#startSignalAbortedButFlowNotDoneTimer();
            });
          }
        }
      }

      return result.value;
    } else {
      // └> the iterator threw an error

      if (this.#signal.aborted) {
        // └> the signal is aborted

        if (result.error !== this.#signal.reason) {
          // └> the iterator threw with a different error than the signal's reason

          if (FlowReader.debugMode) {
            console.warn(
              'The `AsyncIterator` threw an error while the signal of this flow was aborted. This error is expected to be `signal.reason`.',
            );
          }
        }
      } else {
        // └> the signal is not aborted
        // => the flow ends with an error
      }

      throw result.error;
    }
  }

  next(): Promise<IteratorResult<GValue, void>> {
    return this.#iterate((): Promise<IteratorResult<GValue, void>> => this.#iterator.next());
  }

  throw(error?: unknown): Promise<IteratorResult<GValue, void>> {
    return this.#iterate((): Promise<IteratorResult<GValue, void>> => this.#iterator.throw(error));
  }

  return(): Promise<IteratorResult<GValue, void>> {
    return this.#iterate((): Promise<IteratorResult<GValue, void>> => this.#iterator.return());
  }

  [Symbol.asyncIterator](): AsyncIterableIterator<GValue, void, void> {
    return this;
  }

  async [Symbol.asyncDispose](): Promise<void> {
    await this.return();
  }
}

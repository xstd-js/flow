import { type ReadableFlow } from '../../../readable-flow.js';

export interface FlowTransformFunction<GIn, GOut> {
  (flow: ReadableFlow<GIn>): ReadableFlow<GOut>;
}

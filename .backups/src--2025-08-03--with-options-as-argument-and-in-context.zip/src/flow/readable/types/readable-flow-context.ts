import { FlowFactoryContext } from '../../flow/flow.js';

export type ReadableFlowContext<GOptions> = FlowFactoryContext<void, void, GOptions>;

import { type SourceReadResultNotification } from '../../shared/source-read-result-notification.js';

/**
 * @deprecated
 */
export interface SourceForEachFunction<GValue> {
  (notification: SourceReadResultNotification<GValue>): PromiseLike<void> | void;
}

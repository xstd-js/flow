import { type FlowError } from '../../../../shared/flow-error.js';
import { type SourceReadResultNotification } from '../../shared/source-read-result-notification.js';

export interface SourceInspectOptions<GValue> {
  readonly open?: () => void;
  readonly read?: (notification: SourceReadResultNotification<GValue>) => void;
  readonly next?: (value: GValue) => void;
  readonly error?: (error: FlowError) => void;
  readonly close?: (reason?: unknown) => void;
}

import { type SourceReadResultNotification } from '../../shared/source-read-result-notification.js';
import { type SourceLike } from '../../source-like.js';

export interface SourceFlatMapFunction<GIn, GOut> {
  (notification: SourceReadResultNotification<GIn>): SourceLike<GOut>;
}

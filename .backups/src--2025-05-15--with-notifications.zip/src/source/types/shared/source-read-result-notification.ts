import { FlowError } from '../../../shared/flow-error.js';
import { ErrorNotification } from '../../../shared/notifications/error/error-notification.js';
import { NextNotification } from '../../../shared/notifications/next/next-notification.js';

export type SourceReadResultNotification<GValue> =
  | NextNotification<GValue>
  | ErrorNotification<FlowError>;

import { ReadableFlow } from '../../flow/readable/readable-flow.js';
import { CloseHandle } from '../../handle/handle.js';
import { PushToPullOptions } from '../../flow/bridge/types/push-to-pull-options.js';

export interface SyncWriteToFlowBridgeOptions extends PushToPullOptions {
  readonly close?: CloseHandle;
}

interface PendingWrite<GValue> {
  readonly value: GValue;
  readonly expirationDate: number;
}

export class SyncWriteToFlowBridge<GValue> {
  readonly #bufferSize: number;
  readonly #windowTime: number;

  readonly #pendingWrites: PendingWrite<GValue>[];
  #pendingRead: PromiseWithResolvers<GValue> | undefined;

  readonly #closed: boolean;
  #closeReason: unknown;

  readonly #flow: ReadableFlow<GValue>;

  constructor({
    bufferSize = Number.POSITIVE_INFINITY,
    windowTime = Number.POSITIVE_INFINITY,
    close = (): void => {},
  }: SyncWriteToFlowBridgeOptions = {}) {
    this.#bufferSize = Math.max(0, bufferSize);
    this.#windowTime = Math.max(0, windowTime);
    this.#pendingWrites = [];

    this.#closed = false;

    this.#flow = new ReadableFlow<GValue>(
      async (): Promise<GValue> => {
        // remove expired pending writes from the queue
        this.#removeExpiredPendingWrites();

        if (this.#pendingWrites.length > 0) {
          // └> write data are available (read operation occurs after write operation)
          // return the oldest data entry
          return this.#pendingWrites.shift()!.value;
        } else {
          // └> no write data are available (read operation occurs before write operation)
          this.throwIfClosed();

          if (this.#pendingRead === undefined) {
            // └> no read operation is currently in progress (enables concurrent reads)
            // create a promise for the reader that resolves on the next write
            this.#pendingRead = Promise.withResolvers<GValue>();
          }

          // wait for the next write operation
          return await this.#pendingRead!.promise;
        }
      },
      (reason: unknown): PromiseLike<void> | void => {
        if (this.#pendingRead !== undefined) {
          this.#pendingRead.reject(reason);
        }
        return close(reason);
      },
    );
  }

  #removeExpiredPendingWrites(): void {
    const now: number = Date.now();
    while (this.#pendingWrites.length > 0 && this.#pendingWrites[0].expirationDate < now) {
      this.#pendingWrites.shift();
    }
  }

  get flow(): ReadableFlow<GValue> {
    return this.#flow;
  }

  write(value: GValue): void {
    this.throwIfClosed();
    this.#flow.throwIfClosed();

    if (this.#pendingRead === undefined) {
      // └> if the write operation occurs before the read operation

      if (this.#bufferSize > 0 && this.#windowTime > 0) {
        // └> if queuing is enabled
        // => register the write operation in the queue
        // remove expired pending writes
        this.#removeExpiredPendingWrites();

        // queue this write
        this.#pendingWrites.push({
          value,
          expirationDate: Date.now() + this.#windowTime,
        });

        // remove data if it exceeds the maximum buffer size
        if (this.#pendingWrites.length > this.#bufferSize) {
          this.#pendingWrites.shift();
        }
      }
    } else {
      // └> if the write operation occurs after the read operation
      // resolve the pending read operation
      this.#pendingRead.resolve(value);
      this.#pendingRead = undefined;
    }
  }

  get closed(): boolean {
    return this.#closed;
  }

  throwIfClosed(): void {
    if (this.#closed) {
      throw this.#closeReason;
    }
  }

  close(reason: unknown = new Error('Closed without reason.')): void {
    if (!this.#closed) {
      this.#closeReason = reason;
      this.#pendingWrites.length = 0;
      if (this.#pendingRead !== undefined) {
        this.#pendingRead.reject(reason);
      }
    }
  }

  [Symbol.dispose](): void {
    return this.close();
  }
}

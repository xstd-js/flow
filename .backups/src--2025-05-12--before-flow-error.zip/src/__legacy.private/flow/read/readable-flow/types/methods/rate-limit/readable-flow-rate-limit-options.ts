export interface ReadableFlowRateLimitOptions {
  readonly includeReadDuration?: boolean;
}

export interface PushToPullOptions {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

import { FlowReader } from '../read/flow-reader/flow-reader.js';
import { ReadableFlow } from '../read/readable-flow/readable-flow.js';

/*---------------------*/

/*---------------------*/

export interface FlowConsumer<GValue> {
  (readable: ReadableFlow<GValue>): any;
}

export async function logFlow<GValue>(readable: ReadableFlow<GValue>): void {
  await using reader: FlowReader<GValue> = await readable.open();

  reader.read();
}

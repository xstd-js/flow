import { sleep } from '@xstd/async-task';
import { block } from '@xstd/block';
import { describe, expect, it } from 'vitest';
import { WebSocketFlow } from './built-in/web-socket/web-socket-flow.js';
import { WritableFlow } from './flow/writable/writable-flow.js';
import { Sink } from './sink/sink.js';
import { Source } from './source/source.js';
import { SourceForEachNotification } from './source/types/methods/for-each/source-for-each-function.js';

describe('isSignalOrSignalFnc', () => {
  it('is a signal', async () => {
    const controller = new AbortController();

    const { up, down } = new WebSocketFlow('wss://echo.websocket.org');

    await Promise.all([
      block(async () => {
        const data = await down.open(controller.signal);

        while (true) {
          console.log('read', await data.read());
        }
      }),
      block(async () => {
        await up.drain(
          Source.bridge(async (writable: WritableFlow<any>) => {
            while (!controller.signal.aborted) {
              const value: string = new Date().toISOString();
              console.log('write', value);
              await writable.write(value);
              await sleep(1500);
            }
          }),
        );
      }),
      block(async () => {
        await sleep(3000);
        controller.abort();
      }),
    ]);

    // while (!controller.signal.aborted) {
    //   const value: string = new Date().toISOString();
    //   console.log('write', value);
    //   await writable.write(value);
    //   await sleep(1500);
    // }
    expect(0).toBe(0);
  });
});

/*--*/

const LOG_SINK = new Sink<unknown>(
  (source: Source<unknown>, signal?: AbortSignal): Promise<void> => {
    return source.forEach((entry: SourceForEachNotification<unknown>): void => {
      if (entry.type === 'next') {
        console.log(entry.value);
      } else {
        console.error(entry.error);
      }
    }, signal);
  },
);

/*-----*/

// export async function debugFlowV2() {
//   const a = new Source<number>(null as any);
//   const b = a.map(() => 8);
//
//   await LOG_SINK.drain(b);
// }

import { type BaseNotification } from './base-notification.js';

export type GenericNotification = BaseNotification<string>;

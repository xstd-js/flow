export interface BaseNotification<GType extends string> {
  readonly type: GType;
}

import { type GenericNotification } from '../generic-notification.js';
import { type NextNotification } from './next-notification.js';

export function isNextNotification<GValue>(
  notification: GenericNotification,
): notification is NextNotification<GValue> {
  return notification.type === 'next';
}

import { type GenericNotification } from '../generic-notification.js';
import { type ErrorNotification } from './error-notification.js';

export function isErrorNotification<GError = unknown>(
  notification: GenericNotification,
): notification is ErrorNotification<GError> {
  return notification.type === 'error';
}

import { type BaseNotification } from '../base-notification.js';

export interface ErrorNotification<GError = unknown> extends BaseNotification<'error'> {
  readonly error: GError;
}

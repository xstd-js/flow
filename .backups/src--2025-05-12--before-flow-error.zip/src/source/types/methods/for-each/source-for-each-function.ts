import { FlowError } from '../../../../shared/flow-error.js';
import { ErrorNotification } from '../../../../shared/notifications/error/error-notification.js';
import { NextNotification } from '../../../../shared/notifications/next/next-notification.js';

export type SourceForEachNotification<GValue> =
  | NextNotification<GValue>
  | ErrorNotification<FlowError>;

export interface SourceForEachFunction<GValue> {
  (notification: SourceForEachNotification<GValue>): PromiseLike<void> | void;
}

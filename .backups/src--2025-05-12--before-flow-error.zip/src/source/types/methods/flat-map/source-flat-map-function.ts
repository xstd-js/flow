import { FlowError } from '../../../../shared/flow-error.js';
import { ErrorNotification } from '../../../../shared/notifications/error/error-notification.js';
import { NextNotification } from '../../../../shared/notifications/next/next-notification.js';
import { SourceLike } from '../../source-like.js';

export type SourceFlatMapNotification<GValue> =
  | NextNotification<GValue>
  | ErrorNotification<FlowError>;

export interface SourceFlatMapFunction<GIn, GOut> {
  (notification: SourceFlatMapNotification<GIn>): SourceLike<GOut>;
}

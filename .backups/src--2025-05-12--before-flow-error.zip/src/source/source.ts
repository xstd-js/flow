import { isAsyncGeneratorFunction } from '@xstd/async-generator';
import { sleep } from '@xstd/async-task';
import { listen } from '@xstd/disposable';
import {
  FilterFunction,
  FilterFunctionWithSubType,
  MapFilterFunction,
  MapFunction,
} from '@xstd/functional';
import { PushToPullOptions } from '../flow/bridge/types/push-to-pull-options.js';
import { WritableFlowToReadableFlowBridge } from '../flow/bridge/writable-flow-to-readable-flow-bridge.js';
import { ReadableFlow } from '../flow/readable/readable-flow.js';
import { Gate, OpenGate } from '../gate/gate.js';
import { AsyncQueue } from '../shared/classes/async-queue.js';
import { FlowError } from '../shared/flow-error.js';
import { asyncIteratorReturnAll } from '../shared/functions/.private/async-iterator-return-all.js';
import { iteratorReturnAll } from '../shared/functions/.private/iterator-return-all.js';
import { newErrorNotification } from '../shared/notifications/error/new-error-notification.js';
import { newNextNotification } from '../shared/notifications/next/new-next-notification.js';
import { SourceFlatMapFunction } from './types/methods/flat-map/source-flat-map-function.js';
import {
  SourceForEachFunction,
  SourceForEachNotification,
} from './types/methods/for-each/source-for-each-function.js';
import { SourceRateLimitOptions } from './types/methods/rate-limit/source-rate-limit-options.js';
import { SourceLike } from './types/source-like.js';
import { SourceBridge } from './types/static-methods/bridge/source-bridge.js';

export type SourceFeature = 'queued' | 'rate-limited' | string;

export interface SourceOptions {
  readonly features?: Iterable<SourceFeature>;
}

export class Source<GValue> extends Gate<ReadableFlow<GValue>> {
  /**
   * Creates a `Source` from:
   *  - a `Source`
   *  - or an `AsyncGeneratorFunction`
   *  - or an `AsyncIterable`
   *  - or an `Iterable`
   *  - or a `Promise`
   */
  static from<GValue>(input: SourceLike<GValue>): Source<GValue> {
    if (input instanceof Source) {
      return input;
    }

    if (isAsyncGeneratorFunction<[signal: AbortSignal], GValue, void, void>(input)) {
      return this.#fromAsyncGeneratorFunction<GValue>(input);
    }

    if (Symbol.asyncIterator in input) {
      return this.#fromAsyncIterable<GValue>(input);
    }

    if (Symbol.iterator in input) {
      return this.#fromIterable<GValue>(input);
    }

    if (input instanceof Promise) {
      return this.#fromPromise<GValue>(input);
    }

    throw new Error('Not a valid SourceLike.');
  }

  static #fromAsyncGeneratorFunction<GValue>(
    fnc: (signal: AbortSignal) => AsyncIterator<GValue, void, void>,
  ): Source<GValue> {
    return new Source<GValue>((): ReadableFlow<GValue> => {
      const controller = new AbortController();
      const iterator: AsyncIterator<GValue, void, void> = fnc(controller.signal);

      return new ReadableFlow<GValue>(
        async (signal: AbortSignal): Promise<GValue> => {
          using _signalListener: Disposable = listen(signal, 'abort', (): void => {
            controller.abort(signal.reason);
          });

          let result: IteratorResult<GValue>;

          try {
            result = await iterator.next();
          } catch (error: unknown) {
            throw FlowError.fatal({ cause: error });
          }

          if (result.done) {
            throw FlowError.complete();
          }

          return result.value;
        },
        (): Promise<void> => {
          return asyncIteratorReturnAll(iterator);
        },
      );
    });
  }

  static #fromAsyncIterable<GValue>(iterable: AsyncIterable<GValue>): Source<GValue> {
    return this.#fromAsyncGeneratorFunction(iterable[Symbol.asyncIterator]);
  }

  static #fromIterable<GValue>(iterable: Iterable<GValue>): Source<GValue> {
    return new Source<GValue>((): ReadableFlow<GValue> => {
      const iterator: Iterator<GValue> = iterable[Symbol.iterator]();

      return new ReadableFlow<GValue>(
        (): GValue => {
          let result: IteratorResult<GValue>;

          try {
            result = iterator.next();
          } catch (error: unknown) {
            throw FlowError.fatal({ cause: error });
          }

          if (result.done) {
            throw FlowError.complete();
          }

          return result.value;
        },
        (): void => {
          iteratorReturnAll(iterator);
        },
      );
    });
  }

  static #fromPromise<GValue>(promise: Promise<GValue>): Source<GValue> {
    return new Source<GValue>((): ReadableFlow<GValue> => {
      let done: boolean = false;

      return new ReadableFlow<GValue>(
        async (): Promise<GValue> => {
          if (done) {
            throw FlowError.complete();
          }

          try {
            return await promise;
          } catch (error: unknown) {
            throw FlowError.fatal({ cause: error });
          } finally {
            done = true;
          }
        },
        (): void => {},
      );
    });
  }

  /**
   * Creates a `Source` from an `EventTarget`.
   */
  static when<GEvent extends Event>(
    target: EventTarget,
    type: string,
    options?: PushToPullOptions,
  ): Source<GEvent> {
    return new Source<GEvent>((): ReadableFlow<GEvent> => {
      const { writable, readable } = new WritableFlowToReadableFlowBridge<GEvent>({
        ...options,
        close: (reason?: unknown): Promise<void> => {
          stopListener[Symbol.dispose]();
          return writable.close(reason);
        },
      });

      const stopListener: Disposable = listen(target, type, (event: Event): void => {
        writable.write(event as GEvent).catch((): void => {}); // silent error
      });

      return readable;
    });
  }

  /**
   * @experimental
   */
  static bridge<GValue>(bridge: SourceBridge<GValue>, options?: PushToPullOptions): Source<GValue> {
    return new Source<GValue>(async (): Promise<ReadableFlow<GValue>> => {
      const { writable, readable } = new WritableFlowToReadableFlowBridge<GValue>(options);

      Promise.try((): PromiseLike<void> | void => bridge(writable)).then(
        (): void => {
          writable.close();
        },
        (reason: unknown): void => {
          writable.close(reason);
        },
      );

      return readable;
    });
    // TODO add a feature ?
  }

  readonly #features: ReadonlySet<SourceFeature>;

  constructor(open: OpenGate<ReadableFlow<GValue>>, options?: SourceOptions) {
    super(open);
    this.#features =
      options === undefined || options.features === undefined
        ? new Set<SourceFeature>()
        : options.features instanceof Set
          ? options.features
          : new Set<SourceFeature>(options.features);
  }

  get features(): ReadonlySet<SourceFeature> {
    return this.#features;
  }

  /* TRANSFORM THE DATA */

  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): Source<GNewValue> {
    return new Source<GNewValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GNewValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GNewValue>(
          async (): Promise<GNewValue> => {
            return mapFnc(await readable.read());
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  filter<GNewValue extends GValue>(
    filterFnc: FilterFunctionWithSubType<GValue, GNewValue>,
  ): Source<GNewValue>;
  filter(filterFnc: FilterFunction<GValue>): Source<GValue>;
  filter(filterFnc: FilterFunction<GValue>): Source<GValue> {
    if (!this.#features.has('queued') && !this.#features.has('rate-limited')) {
      throw new Error('Must be queued or rate-limited to use filter');
    }

    return new Source<GValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GValue>(
          async (): Promise<GValue> => {
            while (true) {
              const value: GValue = await readable.read();
              if (filterFnc(value)) {
                return value;
              }
            }
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  mapFilter<GNewValue>(mapFilterFnc: MapFilterFunction<GValue, GNewValue>): Source<GNewValue> {
    if (!this.#features.has('queued') && !this.#features.has('rate-limited')) {
      throw new Error('Must be queued or rate-limited to use mapFilter');
    }

    return new Source<GNewValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GNewValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GNewValue>(
          async (): Promise<GNewValue> => {
            while (true) {
              const value: GNewValue | null = mapFilterFnc(await readable.read());
              if (value !== null) {
                return value;
              }
            }
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  /* TRUNCATE THE FLOW */

  take(count: number): Source<GValue> {
    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to use take');
    }

    return new Source<GValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GValue>(
          async (): Promise<GValue> => {
            if (count <= 0) {
              throw FlowError.complete();
            }
            const value: GValue = await readable.read();
            count--;
            return value;
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  drop(count: number): Source<GValue> {
    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to use drop');
    }

    return new Source<GValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GValue>(
          async (): Promise<GValue> => {
            while (count > 0) {
              await readable.read();
              count--;
            }
            return readable.read();
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  /* TRANSFORM THE FLOW */

  flatMap<GNewValue>(flatMapFnc: SourceFlatMapFunction<GValue, GNewValue>): Source<GNewValue> {
    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to use flatMap');
    }

    return new Source<GNewValue>(async (signal?: AbortSignal): Promise<ReadableFlow<GNewValue>> => {
      const readable: ReadableFlow<GValue> = await this.open(signal);
      let innerReadable: ReadableFlow<GNewValue> | undefined;
      let isTerminal: boolean = false;

      return new ReadableFlow<GNewValue>(
        async (): Promise<GNewValue> => {
          while (true) {
            if (innerReadable === undefined) {
              let value!: GValue;
              let error: FlowError | undefined;

              try {
                value = await readable.read();
              } catch (readError: unknown) {
                error = FlowError.of(readError);
              }

              let notification: SourceForEachNotification<GValue>;

              if (error === undefined) {
                notification = newNextNotification(value);
              } else {
                isTerminal = error.type === 'complete' || error.type === 'fatal';

                notification = newErrorNotification(error);
              }

              let innerSourceLike: SourceLike<GNewValue>;

              try {
                innerSourceLike = flatMapFnc(notification);
              } catch (error: unknown) {
                throw FlowError.fatal({ cause: error });
              }

              // if (errored) {
              //   if (error instanceof TerminalError) {
              //     isTerminal = true;
              //   }
              //
              //   if (errorFnc === undefined) {
              //     throw error;
              //   }
              //
              //   try {
              //     innerSource = errorFnc(error);
              //   } catch (error: unknown) {
              //     if (error instanceof TerminalError) {
              //       throw error;
              //     }
              //     // reportError(error);
              //     throw TerminalError.dirty({ cause: error });
              //   }
              // } else {
              //   if (readFnc === undefined) {
              //     return value;
              //   }
              //
              //   try {
              //     innerSource = readFnc(value);
              //   } catch (error: unknown) {
              //     if (error instanceof TerminalError) {
              //       throw error;
              //     }
              //     // reportError(error);
              //     throw TerminalError.dirty({ cause: error });
              //   }
              // }
              //
              // const innerReadable: ReadableFlow<GNewValue> =
              //   ReadableFlow.from<GNewValue>(innerSource);
              //
              // innerReadable = await innerReadable.open(signal);
            }

            try {
              return await innerReadable.read();
            } catch (error: unknown) {
              if (!(error instanceof TerminalError)) {
                throw error;
              }

              try {
                await innerReadable.close();
              } finally {
                innerReadable = undefined;

                if (isTerminal) {
                  throw error;
                }
              }
            }
          }
        },
        async (reason: unknown): Promise<void> => {
          try {
            if (innerReadable !== undefined) {
              await innerReadable.close(reason);
            }
          } finally {
            await readable.close(reason);
          }

          // const stack = new AsyncDisposableStack();
          // stack.use(reader);
          // if (innerReader !== undefined) {
          //   stack.use(innerReader);
          // }
          // await stack.disposeAsync();

          // if (innerReader !== undefined) {
          //   try {
          //     await innerReader.close(reason);
          //   } catch (innerReaderError: unknown) {
          //     try {
          //       await reader.close(reason);
          //       return;
          //     } catch (readerError: unknown) {
          //       throw new SuppressedError(readerError, innerReaderError);
          //     }
          //   }
          // }
          //
          // await reader.close(reason);
        },
      );
    });
  }

  /* INSPECT THE FLOW */

  finally(finallyFnc: () => PromiseLike<void> | void): Source<GValue> {
    return new Source<GValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);

        return new ReadableFlow<GValue>(
          (): Promise<GValue> => {
            return readable.read();
          },
          async (reason: unknown): Promise<void> => {
            try {
              await finallyFnc();
            } finally {
              await readable.close(reason);
            }
          },
        );
      },
      {
        features: this.#features,
      },
    );
  }

  /* MODIFY THE QUEUE */

  queued(): Source<GValue> {
    if (this.#features.has('queued')) {
      throw new Error('Already queued');
    }

    return new Source<GValue>(
      async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
        const readable: ReadableFlow<GValue> = await this.open(signal);
        const queue: AsyncQueue = new AsyncQueue();

        return new ReadableFlow<GValue>(
          (): Promise<GValue> => {
            return queue.enqueue((): Promise<GValue> => {
              return readable.read();
            });
          },
          (reason: unknown): Promise<void> => {
            return readable.close(reason);
          },
        );
      },
      {
        features: [...this.#features, 'queued'],
      },
    );
  }

  rateLimit(
    duration: number,
    { includeReadDuration = true }: SourceRateLimitOptions = {},
  ): Source<GValue> {
    if (duration <= 0) {
      return this;
    }

    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to rate-limit');
    }

    if (this.#features.has('rate-limited')) {
      throw new Error('Already rate-limited');
    }

    return new Source<GValue>(async (signal?: AbortSignal): Promise<ReadableFlow<GValue>> => {
      const readable: ReadableFlow<GValue> = await this.open(signal);
      let minReadDate: number = Date.now();

      return new ReadableFlow<GValue>(
        async (signal: AbortSignal): Promise<GValue> => {
          const remainingDuration: number = minReadDate - Date.now();

          if (remainingDuration > 0) {
            await sleep(remainingDuration, signal);
          }

          if (includeReadDuration) {
            minReadDate = Date.now() + duration;

            return readable.read();
          } else {
            try {
              return await readable.read();
            } finally {
              minReadDate = Date.now() + duration;
            }
          }
        },
        (reason: unknown): Promise<void> => {
          return readable.close(reason);
        },
      );
    });
  }

  /* PROMISE-BASED RETURN */

  async forEach(forEachFnc: SourceForEachFunction<GValue>, signal?: AbortSignal): Promise<void> {
    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to use forEach');
    }

    await using readable: ReadableFlow<GValue> = await this.open(signal);

    using stack: DisposableStack = new DisposableStack();

    if (signal !== undefined) {
      stack.use(
        listen(signal, 'abort', (): void => {
          readable.close(signal.reason);
        }),
      );
    }

    while (true) {
      let value!: GValue;
      let error: FlowError | undefined;

      try {
        value = await readable.read();
      } catch (readError: unknown) {
        error = FlowError.of(readError);
      }

      let notification: SourceForEachNotification<GValue>;

      if (error === undefined) {
        notification = newNextNotification(value);
      } else {
        if (error.type === 'complete') {
          return;
        } else if (error.type === 'fatal') {
          throw error;
        }

        notification = newErrorNotification<FlowError>(error as FlowError);
      }

      await forEachFnc(notification);
    }
  }

  async toArray(signal?: AbortSignal): Promise<GValue[]> {
    if (!this.#features.has('queued')) {
      throw new Error('Must be queued to use toArray');
    }

    await using readable: ReadableFlow<GValue> = await this.open(signal);

    using stack: DisposableStack = new DisposableStack();

    if (signal !== undefined) {
      stack.use(
        listen(signal, 'abort', (): void => {
          readable.close(signal.reason);
        }),
      );
    }

    const values: GValue[] = [];

    while (true) {
      try {
        values.push(await readable.read());
      } catch (error: unknown) {
        error = FlowError.of(error);

        if ((error as FlowError).type === 'complete') {
          return values;
        } else {
          throw error;
        }
      }
    }
  }

  async first(signal?: AbortSignal): Promise<GValue> {
    await using readable: ReadableFlow<GValue> = await this.open(signal);

    using stack: DisposableStack = new DisposableStack();

    if (signal !== undefined) {
      stack.use(
        listen(signal, 'abort', (): void => {
          readable.close(signal.reason);
        }),
      );
    }

    try {
      return await readable.read();
    } catch (error: unknown) {
      error = FlowError.of(error);

      if ((error as FlowError).type === 'complete') {
        throw new Error('Complete without sending a value.');
      }

      throw error;
    }
  }

  async last(signal?: AbortSignal): Promise<GValue> {
    await using readable: ReadableFlow<GValue> = await this.open(signal);

    using stack: DisposableStack = new DisposableStack();

    if (signal !== undefined) {
      stack.use(
        listen(signal, 'abort', (): void => {
          readable.close(signal.reason);
        }),
      );
    }

    while (true) {
      let value: GValue;
      let hasValue: boolean = false;

      try {
        value = await readable.read();
        hasValue = true;
      } catch (error: unknown) {
        error = FlowError.of(error);

        if ((error as FlowError).type === 'complete') {
          if (hasValue) {
            return value!;
          }
          throw new Error('Complete without sending a value.');
        }

        throw error;
      }
    }
  }

  /* CAST TO OTHER KIND OF STREAMS */

  toReadableStream(): ReadableStream<GValue> {
    let abortController: AbortController = new AbortController();
    let readable: ReadableFlow<GValue>;

    return new ReadableStream({
      start: async (): Promise<void> => {
        readable = await this.open(abortController.signal);
      },
      pull: async (controller: ReadableStreamDefaultController<GValue>): Promise<void> => {
        let value: GValue;

        try {
          value = await readable.read();
        } catch (error: unknown) {
          error = FlowError.of(error);

          if ((error as FlowError).type === 'complete') {
            controller.close();
          } else {
            controller.error(error);
          }
          return;
        }

        controller.enqueue(value);
      },
      cancel: async (reason?: any): Promise<void> => {
        abortController.abort(reason);
        await readable.close(reason);
      },
    });
  }

  async *toAsyncGenerator(): AsyncGenerator<GValue, void, void> {
    await using readable: ReadableFlow<GValue> = await this.open();

    try {
      yield await readable.read();
    } catch (error: unknown) {
      error = FlowError.of(error);

      if ((error as FlowError).type !== 'complete') {
        throw error;
      }
    }
  }

  [Symbol.asyncIterator](): AsyncGenerator<GValue, void, void> {
    return this.toAsyncGenerator();
  }
}

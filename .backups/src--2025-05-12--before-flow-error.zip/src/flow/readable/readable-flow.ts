import { CloseHandle, Handle } from '../../handle/handle.js';

export interface ReadFlow<GValue> {
  (signal: AbortSignal): PromiseLike<GValue> | GValue;
}

export class ReadableFlow<GValue> extends Handle {
  readonly #read: ReadFlow<GValue>;

  constructor(read: ReadFlow<GValue>, close: CloseHandle) {
    super(close);
    this.#read = read;
  }

  async read(): Promise<GValue> {
    return super.run(this.#read);
  }
}

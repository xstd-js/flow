import { CustomError, type CustomErrorOptions } from '@xstd/custom-error';

export interface TerminalErrorOptions extends CustomErrorOptions {
  readonly clean: boolean;
}

export class TerminalError extends CustomError<'TerminalError'> {
  static clean(options?: Omit<TerminalErrorOptions, 'clean'>): TerminalError {
    return new TerminalError({
      ...options,
      clean: true,
    });
  }

  static dirty(options?: Omit<TerminalErrorOptions, 'clean'>): TerminalError {
    return new TerminalError({
      ...options,
      clean: false,
    });
  }

  static handle<GReturn>(
    error: unknown,
    onClean: (error: unknown) => GReturn = DEFAULT_REPORT_ON_CLEAN_FUNCTION,
    onError: (error: unknown) => GReturn = DEFAULT_REPORT_ON_ERROR_FUNCTION,
  ): GReturn {
    if (error instanceof TerminalError) {
      if (error.clean) {
        return onClean(error.cause);
      }
      return onError(error.cause);
    }

    return onError(error);
  }

  readonly clean: boolean;

  constructor({ clean, ...options }: TerminalErrorOptions) {
    super('TerminalError', options);
    this.clean = clean;
  }
}

const DEFAULT_REPORT_ON_CLEAN_FUNCTION = (error: unknown): never => {
  throw error;
};

const DEFAULT_REPORT_ON_ERROR_FUNCTION = (error: unknown): never => {
  throw error;
};

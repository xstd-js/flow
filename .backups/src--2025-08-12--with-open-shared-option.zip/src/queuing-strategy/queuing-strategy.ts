export interface QueuingStrategy<GValue, GData> {
  readonly push: QueuingStrategyOnPush<GValue, GData>;
  readonly pull: QueuingStrategyOnPull<GValue, GData>;
}

export interface QueuingStrategyOnPush<GValue, GData> {
  (
    value: GValue,
    queued: readonly QueuedValue<GValue, GData>[],
  ): readonly QueuedValue<GValue, GData>[];
}

export interface QueuingStrategyOnPull<GValue, GData> {
  (queued: readonly QueuedValue<GValue, GData>[]): readonly QueuedValue<GValue, GData>[];
}

export interface QueuedValue<GValue, GData> {
  readonly value: GValue;
  readonly data: GData;
}

export class FiFoQueue<GData> {
  readonly #queue: GData[];

  constructor() {
    this.#queue = [];
  }

  #throwIfEmpty(): void {
    if (this.#queue.length === 0) {
      throw new Error('Queue is empty');
    }
  }

  get size(): number {
    return this.#queue.length;
  }

  get first(): GData {
    this.#throwIfEmpty();
    return this.#queue[0];
  }

  push(data: GData): void {
    this.#queue.push(data);
  }

  pop(): GData {
    this.#throwIfEmpty();
    return this.#queue.shift()!;
  }

  clear(): void {
    this.#queue.length = 0;
  }
}

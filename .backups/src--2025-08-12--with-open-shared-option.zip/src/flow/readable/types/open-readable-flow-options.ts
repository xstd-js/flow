export interface OpenReadableFlowOptions {
  readonly mode?: OpenReadableFlowMode;
}

export type OpenReadableFlowMode = 'new' | 'shared';

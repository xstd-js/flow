import { type ReadableFlowArguments } from '../readable-flow.js';
import { type ReadableFlowContext } from './readable-flow-context.js';
import { type ReadableFlowIterator } from './readable-flow-iterator.js';

export interface ReadableFlowFactory<GValue> {
  (ctx: ReadableFlowContext, ...args: ReadableFlowArguments<GValue>): ReadableFlowIterator<GValue>;
}

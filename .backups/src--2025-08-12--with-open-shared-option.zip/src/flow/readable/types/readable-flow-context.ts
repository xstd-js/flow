import { type FlowContext } from '../../flow/flow.js';

export type ReadableFlowContext = FlowContext<void, void>;

// export interface ReadableFlowContext extends FlowContext<void, void> {
// }

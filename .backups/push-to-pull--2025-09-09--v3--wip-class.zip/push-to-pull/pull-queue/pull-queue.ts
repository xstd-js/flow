import {
  type AsyncEnumerator,
  type AsyncEnumeratorObject,
  type EnumeratorResult,
} from '../../../../enumerable/enumerable.js';

export class PullQueue<GValue> implements AsyncEnumeratorObject<void, GValue, void> {
  readonly #enumerator: AsyncEnumerator<void, GValue, void>;

  constructor(enumerator: AsyncEnumerator<void, GValue, void>) {
    this.#enumerator = enumerator;
  }

  next(): Promise<EnumeratorResult<GValue, void>> {
    return this.#enumerator.next();
  }

  throw(error?: unknown): Promise<EnumeratorResult<GValue, void>> {
    return this.#enumerator.throw(error);
  }

  return(): Promise<EnumeratorResult<GValue, void>> {
    return this.#enumerator.return();
  }

  [Symbol.asyncIterator](): AsyncEnumeratorObject<void, GValue, void> {
    return this;
  }

  async [Symbol.asyncDispose](): Promise<void> {
    await this.return();
  }
}

import { type PullQueue } from '../pull-queue/pull-queue.js';
import { type PushQueue } from '../push-queue/push-queue.js';

export interface PushToPullQueue<GValue> {
  readonly push: PushQueue<GValue>;
  readonly pull: PullQueue<GValue>;
}

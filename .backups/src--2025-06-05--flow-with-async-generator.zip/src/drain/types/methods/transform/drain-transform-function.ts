import { type Flow } from '../../../../flow/flow/flow.js';

export interface DrainTransformFunction<GIn, GOut> {
  (flow: Flow<GIn>): Flow<GOut>;
}

import { MapFunction } from '@xstd/functional';
import { FlowIterator } from '../flow/active/active-flow.js';
import {
  flowAsyncBridge,
  FlowAsyncBridge,
  FlowAsyncBridgeResult,
} from '../flow/bridge/async/flow-async-bridge.js';
import { Flow } from '../flow/flow/flow.js';
import { FlowTransformFunction } from '../flow/flow/types/methods/transform/flow-transform-function.js';

export interface DrainFlow<GValue> {
  (flow: Flow<GValue>, signal: AbortSignal): PromiseLike<void> | void;
}

export type DrainBridgeResult<GValue> = [
  bridge: FlowAsyncBridge<GValue>,
  finishedPromise: Promise<void>,
];

export class Drain<GValue> {
  readonly #drain: DrainFlow<GValue>;

  constructor(drain: DrainFlow<GValue>) {
    this.#drain = drain;
  }

  async drain(flow: Flow<GValue>, signal: AbortSignal): Promise<void> {
    await this.#drain(flow, signal);
  }

  bridge(signal: AbortSignal): DrainBridgeResult<GValue> {
    const [bridge, flow]: FlowAsyncBridgeResult<GValue> = flowAsyncBridge<GValue>(signal);

    return [
      bridge,
      this.drain(
        new Flow<GValue>(async function* (): FlowIterator<GValue> {
          yield* flow;
        }),
        signal,
      ),
    ];
  }

  /* TRANSFORM */

  transform<GNewValue>(transformFnc: FlowTransformFunction<GNewValue, GValue>): Drain<GNewValue> {
    return new Drain<GNewValue>((flow: Flow<GNewValue>, signal: AbortSignal): Promise<void> => {
      return this.drain(flow.transform<GValue>(transformFnc), signal);
    });
  }

  /* TRANSFORM THE DATA */

  map<GNewValue>(mapFnc: MapFunction<GNewValue, GValue>): Drain<GNewValue> {
    return this.transform((flow: Flow<GNewValue>): Flow<GValue> => flow.map(mapFnc));
    // return new Drain<GNewValue>((flow: Flow<GNewValue>, signal: AbortSignal): Promise<void> => {
    //   return this.drain(flow.map(mapFnc), signal);
    // });
  }
}

import { type Flow } from '../../../flow.js';

export interface FlowTransformFunction<GIn, GOut> {
  (flow: Flow<GIn>): Flow<GOut>;
}

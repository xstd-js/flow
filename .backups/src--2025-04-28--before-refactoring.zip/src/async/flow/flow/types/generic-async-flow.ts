import { type AsyncFlow } from '../async-flow.js';

export type GenericAsyncFlow = AsyncFlow<any, any>;

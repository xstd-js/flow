import { FlowFactoryContext } from '../../flow/flow.js';

export type ReadableFlowContext<GOptions extends object> = FlowFactoryContext<void, void, GOptions>;

export interface AsyncReadableShareOptions {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

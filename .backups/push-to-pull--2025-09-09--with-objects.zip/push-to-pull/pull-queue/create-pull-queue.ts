import {
  type AsyncEnumeratorObject,
  type EnumeratorResult,
} from '../../../../enumerable/enumerable.js';
import { type PullQueue } from './pull-queue.js';

export interface PullQueueNextFunction<GValue> {
  (): Promise<EnumeratorResult<GValue, void>>;
}

export interface PullQueueThrowFunction<GValue> {
  (error?: unknown): Promise<EnumeratorResult<GValue, void>>;
}

export interface PullQueueReturnFunction<GValue> {
  (): Promise<EnumeratorResult<GValue, void>>;
}

export interface CreatePullQueueOptions<GValue> {
  readonly next: PullQueueNextFunction<GValue>;
  readonly throw: PullQueueThrowFunction<GValue>;
  readonly return: PullQueueReturnFunction<GValue>;
}

export function createPullQueue<GValue>(
  options: CreatePullQueueOptions<GValue>,
): PullQueue<GValue> {
  const queue: PullQueue<GValue> = {
    ...options,
    [Symbol.asyncIterator]: (): AsyncEnumeratorObject<void, GValue, void> => {
      return queue;
    },
    [Symbol.asyncDispose]: async (): Promise<void> => {
      await queue.return();
    },
  };

  return queue;
}

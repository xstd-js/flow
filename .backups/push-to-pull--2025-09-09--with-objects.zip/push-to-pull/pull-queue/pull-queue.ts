import { type AsyncEnumeratorObject } from '../../../../enumerable/enumerable.js';

export interface PullQueue<GValue> extends AsyncEnumeratorObject<void, GValue, void> {}

export interface PushQueueNextFunction<GValue> {
  (value: GValue): void;
}

export interface PushQueueErrorFunction {
  (error?: unknown): void;
}

export interface PushQueueCompleteFunction {
  (): void;
}

export interface PushQueue<GValue> {
  readonly next: PushQueueNextFunction<GValue>;
  readonly error: PushQueueErrorFunction;
  readonly complete: PushQueueCompleteFunction;
}

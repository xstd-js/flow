import { aggregateErrors } from '../../../helpers/.private/aggregate-errors.js';
import { type GenericAsyncFlow } from '../../flow/flow/generic-async-flow.js';

/* TYPES */

/**
 * Represents an "entry" (a key/value tuple) of a `MultiAsyncFlow`.
 */
export type MultiAsyncFlowEntry<
  GKey extends string,
  GAsyncFlow extends GenericAsyncFlow,
> = readonly [key: GKey, asyncFlow: GAsyncFlow];

export type GenericMultiAsyncFlowEntry = MultiAsyncFlowEntry<any, any>;

/**
 * Returns the `GKey` of a `MultiAsyncFlowEntry`.
 */
export type InferMultiAsyncFlowEntryKey<GEntry extends GenericMultiAsyncFlowEntry> =
  GEntry extends readonly [key: infer GKey, asyncFlow: any] ? GKey : never;

/**
 * Returns the `GAsyncFlow` of a `MultiAsyncFlowEntry` based on a specific `GKey`.
 */
export type InferMultiAsyncFlowEntryAsyncFlowFromKey<
  GEntry extends GenericMultiAsyncFlowEntry,
  GKey extends string,
> = GEntry extends readonly [key: GKey, asyncFlow: infer GAsyncFlow] ? GAsyncFlow : never;

// STATIC METHODS

// -> .iterable(...)

/**
 * Converts an `Array` of `GenericAsyncFlow`s into a union of `MultiAsyncFlowEntry`.
 */
export type ArrayToMultiAsyncFlowEntry<GArray extends readonly GenericAsyncFlow[]> = {
  [GKey in keyof GArray]: MultiAsyncFlowEntry<`${GKey}`, GArray[GKey]>;
}[number];

/**
 * Converts an `Iterable` of `GenericAsyncFlow`s into a union of `MultiAsyncFlowEntry`.
 */
export type IterableToMultiAsyncFlowEntry<GIterable extends Iterable<GenericAsyncFlow>> =
  GIterable extends Iterable<infer GValue>
    ? GValue extends GenericAsyncFlow
      ? MultiAsyncFlowEntry<`${number}`, GValue>
      : never
    : never;

/* CLASS */

/**
 * Represents a collection of `AsyncFlow`s accessible through a named `key`.
 *
 * @experimental
 */
export class MultiAsyncFlow<GEntry extends GenericMultiAsyncFlowEntry> {
  /**
   * @experimental
   */
  static iterable<GArray extends readonly GenericAsyncFlow[]>(
    array: GArray,
  ): MultiAsyncFlow<ArrayToMultiAsyncFlowEntry<GArray>>;
  static iterable<GIterable extends Iterable<GenericAsyncFlow>>(
    iterable: GIterable,
  ): MultiAsyncFlow<IterableToMultiAsyncFlowEntry<GIterable>>;
  static iterable(array: Iterable<GenericAsyncFlow>): MultiAsyncFlow<GenericMultiAsyncFlowEntry> {
    return new MultiAsyncFlow<GenericMultiAsyncFlowEntry>(
      Array.from(
        array,
        (asyncFLow: GenericAsyncFlow, index: number): GenericMultiAsyncFlowEntry => {
          return [String(index), asyncFLow];
        },
      ),
    );
  }

  readonly #map: ReadonlyMap<string, GenericAsyncFlow>;

  constructor(entries: Iterable<GEntry>) {
    this.#map = new Map<string, GenericAsyncFlow>(entries);
  }

  /**
   * Returns the `AsyncFlow` named `key`.
   */
  get<GKey extends InferMultiAsyncFlowEntryKey<GEntry>>(
    key: GKey,
  ): InferMultiAsyncFlowEntryAsyncFlowFromKey<GEntry, GKey> {
    const asyncFlow: GenericAsyncFlow | undefined = this.#map.get(key);
    if (asyncFlow === undefined) {
      throw new Error(`Key ${JSON.stringify(key)} not found.`);
    }
    return asyncFlow as InferMultiAsyncFlowEntryAsyncFlowFromKey<GEntry, GKey>;
  }

  /**
   * Closes concurrently all the `AsyncFlow`s.
   *
   * Awaits that **all** the `AsyncFlow`s resolve (fulfilled or rejected), before this Promise is resolved.
   * In case or error(s), they're aggregated and the returned Promise rejects.
   */
  close(reason?: unknown): Promise<void> {
    return new Promise<void>((resolve: () => void, reject: (reason?: any) => void): void => {
      let done: number = 0;
      const errors: unknown[] = [];

      const allResolved = (): void => {
        if (errors.length > 0) {
          reject(aggregateErrors(errors));
        } else {
          resolve();
        }
      };

      const resolveOne = (): void => {
        done++;
        if (done === this.#map.size) {
          allResolved();
        }
      };

      for (const asyncFlow of this.#map.values()) {
        asyncFlow.close(reason).then(resolveOne, (error: unknown): void => {
          errors.push(error);
          resolveOne();
        });
      }
    });
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}

import { aggregateErrors } from '../../../helpers/.private/aggregate-errors.js';
import { removeDuplicateAbortSignalErrorFromErrors } from '../../../helpers/.private/remove-duplicate-abort-signal-error-from-errors.js';
import { type AsyncFlowFactory } from '../../flow/factory/async-flow-factory.js';
import { type GenericAsyncFlowFactory } from '../../flow/factory/types/generic-async-flow-factory.js';
import { type GenericAsyncFlow } from '../../flow/flow/generic-async-flow.js';
import {
  type GenericMultiAsyncFlowEntry,
  MultiAsyncFlow,
  type MultiAsyncFlowEntry,
} from '../flow/multi-async-flow.js';

/* TYPES */

/**
 * Represents an "entry" (a key/value tuple) of a `MultiAsyncFlowFactory`.
 */
export type MultiAsyncFlowFactoryEntry<
  GKey extends string,
  GAsyncFlowFactory extends GenericAsyncFlowFactory,
> = readonly [key: GKey, asyncFlowFactory: GAsyncFlowFactory];

export type GenericMultiAsyncFlowFactoryEntry = MultiAsyncFlowFactoryEntry<any, any>;

/**
 * Returns the `GKey` of a `MultiAsyncFlowFactoryEntry`.
 */
export type InferMultiAsyncFlowFactoryEntryKey<GEntry extends GenericMultiAsyncFlowFactoryEntry> =
  GEntry extends readonly [key: infer GKey, asyncFlowFactory: any] ? GKey : never;

/**
 * Returns the `GAsyncFlowFactory` of a `MultiAsyncFlowFactoryEntry` based on a specific `GKey`.
 */
export type InferMultiAsyncFlowFactoryEntryAsyncFlowFromKey<
  GEntry extends GenericMultiAsyncFlowFactoryEntry,
  GKey extends string,
> = GEntry extends readonly [key: GKey, asyncFlowFactory: infer GAsyncFlowFactory]
  ? GAsyncFlowFactory
  : never;

// METHODS

// -> .open(...)

/**
 * Converts from a `MultiAsyncFlowFactoryEntry` to a `MultiAsyncFlowEntry`.
 */
export type MultiAsyncFlowFactoryEntryToMultiAsyncFlowEntry<
  GEntry extends GenericMultiAsyncFlowFactoryEntry,
> = GEntry extends readonly [key: infer GKey, asyncFlowFactory: infer GAsyncFlowFactory]
  ? GKey extends string
    ? GAsyncFlowFactory extends AsyncFlowFactory<infer GAsyncFlow>
      ? MultiAsyncFlowEntry<GKey, GAsyncFlow>
      : never
    : never
  : never;

// -> .mutate(...)

/**
 * A mutate function.
 */
export interface MultiAsyncFlowFactoryMutateFunction<
  GSelf extends MultiAsyncFlowFactory<GenericMultiAsyncFlowFactoryEntry>,
  GOutEntry extends GenericMultiAsyncFlowFactoryEntry,
> {
  (self: GSelf): Iterable<GOutEntry>;
}

/* CLASS */

/**
 * Represents a collection of `AsyncFlowFactories`s accessible through a named `key`.
 *
 * @experimental
 */
export class MultiAsyncFlowFactory<GEntry extends GenericMultiAsyncFlowFactoryEntry> {
  readonly #map: ReadonlyMap<string, GenericAsyncFlowFactory>;

  constructor(entries: Iterable<GEntry>) {
    this.#map = new Map<string, GenericAsyncFlowFactory>(entries);
  }

  /* MAP LIKE */

  /**
   * Returns the `AsyncFlowFactory` named `key`.
   */
  get<GKey extends InferMultiAsyncFlowFactoryEntryKey<GEntry>>(
    key: GKey,
  ): InferMultiAsyncFlowFactoryEntryAsyncFlowFromKey<GEntry, GKey> {
    const asyncFlowFactory: GenericAsyncFlowFactory | undefined = this.#map.get(key);
    if (asyncFlowFactory === undefined) {
      throw new Error(`Key ${JSON.stringify(key)} not found.`);
    }
    return asyncFlowFactory as InferMultiAsyncFlowFactoryEntryAsyncFlowFromKey<GEntry, GKey>;
  }

  [Symbol.iterator](): IterableIterator<GEntry> {
    return this.#map[Symbol.iterator]() as IterableIterator<GEntry>;
  }

  /* ASYNC FLOW FACTORY LIKE */

  /**
   * Opens concurrently all the `AsyncFlowFactories`.
   *
   * Awaits that **all** the `AsyncFlowFactories` resolve (fulfilled or rejected), before this Promise is resolved.
   * In case or error(s), the given signal is aborted, opened `AsyncFlowFactories` are closed,
   * the returned Promise rejects with these errors aggregated.
   */
  async open(
    signal?: AbortSignal,
  ): Promise<MultiAsyncFlow<MultiAsyncFlowFactoryEntryToMultiAsyncFlowEntry<GEntry>>> {
    type GChildEntry = MultiAsyncFlowFactoryEntryToMultiAsyncFlowEntry<GEntry>;
    type GValue = MultiAsyncFlow<GChildEntry>;

    return new Promise<GValue>(
      (resolve: (value: GValue) => void, reject: (reason?: any) => void): void => {
        signal?.throwIfAborted();

        if (this.#map.size === 0) {
          return resolve(new MultiAsyncFlow<GChildEntry>([]));
        }

        const controller: AbortController = new AbortController();
        const sharedSignal: AbortSignal =
          signal === undefined ? controller.signal : AbortSignal.any([signal, controller.signal]);

        const asyncFlows: GenericMultiAsyncFlowEntry[] = [];
        const errors: unknown[] = [];

        const allResolved = (): void => {
          const filteredErrors: readonly unknown[] = removeDuplicateAbortSignalErrorFromErrors(
            sharedSignal,
            errors,
          );

          const multiAsyncFlow = new MultiAsyncFlow<GenericMultiAsyncFlowEntry>(asyncFlows);

          if (filteredErrors.length > 0) {
            const error: unknown = aggregateErrors(filteredErrors);

            multiAsyncFlow.close().then(
              (): void => {
                reject(error);
              },
              (_error: unknown): void => {
                reject(new SuppressedError(_error, error));
              },
            );
          } else {
            resolve(multiAsyncFlow);
          }
        };

        const resolveOne = (): void => {
          if (asyncFlows.length + errors.length === this.#map.size) {
            allResolved();
          }
        };

        for (const [key, asyncFlowFactory] of this.#map.entries()) {
          asyncFlowFactory.open(sharedSignal).then(
            (asyncFlow: GenericAsyncFlow): void => {
              asyncFlows.push([key, asyncFlow]);
              resolveOne();
            },
            (error: unknown): void => {
              errors.push(error);
              controller.abort();
              resolveOne();
            },
          );
        }
      },
    );
  }

  mutate<GOutEntry extends GenericMultiAsyncFlowFactoryEntry>(
    mutateFnc: MultiAsyncFlowFactoryMutateFunction<this, GOutEntry>,
  ): MultiAsyncFlowFactory<GOutEntry> {
    return new MultiAsyncFlowFactory<GOutEntry>(mutateFnc(this));
  }
}

import { type AsyncFlowFactory } from '../async-flow-factory.js';

export type GenericAsyncFlowFactory = AsyncFlowFactory<any>;

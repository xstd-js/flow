export type WebSocketReadValue = string | ArrayBuffer;

import { type FlowError } from '../../../../shared/flow-error.js';
import { type SourceLike } from '../../source-like.js';

export interface SourceFlatMapNextFunction<GIn, GOut> {
  (value: GIn): SourceLike<GOut>;
}

export interface SourceFlatMapErrorFunction<GOut> {
  (error: FlowError): SourceLike<GOut>;
}

export interface SourceFlatMapWithNextOptions<GIn, GOut> {
  readonly next: SourceFlatMapNextFunction<GIn, GOut>;
  readonly error?: undefined;
}

export interface SourceFlatMapWithErrorOptions<GOut> {
  readonly next?: undefined;
  readonly error: SourceFlatMapErrorFunction<GOut>;
}

export interface SourceFlatMapWithNextAndErrorOptions<GIn, GOut> {
  readonly next: SourceFlatMapNextFunction<GIn, GOut>;
  readonly error: SourceFlatMapErrorFunction<GOut>;
}

// export interface SourceFlatMapOptions<GIn, GOut> {
//   readonly next?: SourceFlatMapNextFunction<GIn, GOut>;
//   readonly error?: SourceFlatMapErrorFunction<GOut>;
// }

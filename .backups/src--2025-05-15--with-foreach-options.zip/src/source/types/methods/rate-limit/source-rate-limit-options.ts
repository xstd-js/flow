export interface SourceRateLimitOptions {
  readonly includeReadDuration?: boolean;
}

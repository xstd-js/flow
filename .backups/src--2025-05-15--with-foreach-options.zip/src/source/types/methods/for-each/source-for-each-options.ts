import { FlowError } from '../../../../shared/flow-error.js';

export interface SourceForEachNextFunction<GValue> {
  (value: GValue): PromiseLike<void> | void;
}

export interface SourceForEachErrorFunction {
  (error: FlowError): PromiseLike<void> | void;
}

export interface SourceForEachOptions<GValue> {
  readonly next?: SourceForEachNextFunction<GValue>;
  readonly error?: SourceForEachErrorFunction;
  readonly signal?: AbortSignal;
}

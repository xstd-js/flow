import { FlowError } from '../../../shared/flow-error.js';
import { ErrorNotification } from '../../../shared/notifications.private/error/error-notification.js';
import { NextNotification } from '../../../shared/notifications.private/next/next-notification.js';

export type SourceReadResultNotification<GValue> =
  | NextNotification<GValue>
  | ErrorNotification<FlowError>;

import { type ErrorNotification } from './error-notification.js';

export function newErrorNotification<GError>(error: GError): ErrorNotification<GError> {
  return {
    type: 'error',
    error,
  };
}

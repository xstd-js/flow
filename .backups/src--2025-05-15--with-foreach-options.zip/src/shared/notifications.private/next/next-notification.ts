import { type BaseNotification } from '../base-notification.js';

export interface NextNotification<GValue> extends BaseNotification<'next'> {
  readonly value: GValue;
}

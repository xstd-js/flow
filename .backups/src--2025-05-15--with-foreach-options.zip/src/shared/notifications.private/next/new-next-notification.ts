import { type NextNotification } from './next-notification.js';

export function newNextNotification<GValue>(value: GValue): NextNotification<GValue> {
  return {
    type: 'next',
    value,
  };
}

export interface Enum<GType extends string> {
  readonly type: GType;
}

import { type ReadableFlowContext } from './readable-flow-context.js';
import { type ReadableFlowIterator } from './readable-flow-iterator.js';

export interface ReadableFlowFactory<GValue> {
  (ctx: ReadableFlowContext): ReadableFlowIterator<GValue>;
}

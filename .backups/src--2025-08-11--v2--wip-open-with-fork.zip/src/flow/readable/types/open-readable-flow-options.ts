export interface OpenReadableFlowOptions<GValue> {
  readonly queueingStrategy?: QueuingStrategy<GValue>; // TODO
  readonly mode?: OpenReadableFlowMode;
}

export type OpenReadableFlowMode = 'new' | 'fork' | 'tie';

export interface QueuingStrategy<GValue, GData> {
  readonly push: QueuingStrategyOnPush<GValue, GData>;
  readonly pull: QueuingStrategyOnPull<GValue, GData>;
}

export interface QueuingStrategyOnPush<GValue, GData> {
  (
    value: GValue,
    queued: readonly QueuedValue<GValue, GData>[],
  ): readonly QueuedValue<GValue, GData>[];
}

export interface QueuingStrategyOnPull<GValue, GData> {
  (queued: readonly QueuedValue<GValue, GData>[]): readonly QueuedValue<GValue, GData>[];
}

export interface QueuedValue<GValue, GData> {
  readonly value: GValue;
  readonly data: GData;
}

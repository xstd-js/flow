export type WebSocketUpValue = string | ArrayBufferLike | ArrayBufferView;

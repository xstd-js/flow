export type WebSocketDownValue = string | ArrayBuffer;

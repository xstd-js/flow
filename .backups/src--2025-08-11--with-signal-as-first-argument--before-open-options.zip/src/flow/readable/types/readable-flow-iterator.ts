export type ReadableFlowIterator<GValue> = AsyncGenerator<GValue, void, void>;

import { type FlowContext } from '../../flow/flow.js';

export type ReadableFlowContext = FlowContext<void, void>;

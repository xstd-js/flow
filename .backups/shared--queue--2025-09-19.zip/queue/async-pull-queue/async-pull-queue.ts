import { type AsyncEnumeratorObject } from '../../../enumerable/enumerable.js';
import { type QueueStep } from '../queue-step.js';

export interface AsyncPullQueueStepFunction<GValue> {
  (signal: AbortSignal): PromiseLike<QueueStep<GValue>> | QueueStep<GValue>;
}

export class AsyncPullQueue<GValue> implements AsyncIterable<GValue, void, void> {
  readonly #step: AsyncPullQueueStepFunction<GValue>;
  #queue: Promise<any>;
  // #done: boolean;
  readonly #closeController: AbortController;

  constructor(step: AsyncPullQueueStepFunction<GValue>) {
    this.#step = step;
    this.#queue = Promise.resolve();
    // this.#done = false;
    this.#closeController = new AbortController();
  }

  get closed(): boolean {
    return this.#closeController.signal.aborted;
  }

  throwIfClosed(): void {
    if (this.#closeController.signal.aborted) {
      throw new Error('AsyncPullQueue is closed');
    }
  }

  step(): Promise<QueueStep<GValue>> {
    return (this.#queue = this.#queue.then(
      async (): Promise<QueueStep<GValue>> => {
        this.throwIfClosed();

        const step: QueueStep<GValue> = await this.#step(this.#closeController.signal);

        this.throwIfClosed();

        if (step.type === 'complete') {
          this.#closeController.abort();
        } else if (step.type === 'error') {
          this.#closeController.abort(step.error);
        }

        return step;
      },
      (error: unknown): never => {
        this.#closeController.abort(error);
        throw error;
      },
    ));
  }

  async close(reason?: unknown): Promise<void> {
    if (!this.#closeController.signal.aborted) {
      this.#closeController.abort(reason);
    }

    await this.#queue;
  }

  async *[Symbol.asyncIterator](): AsyncEnumeratorObject<void, GValue, void> {
    while (true) {
      const step: QueueStep<GValue> = await this.step();

      if (step.type === 'next') {
        yield step.value;
      } else if (step.type === 'error') {
        throw step.error;
      } else {
        return;
      }
    }
  }
}

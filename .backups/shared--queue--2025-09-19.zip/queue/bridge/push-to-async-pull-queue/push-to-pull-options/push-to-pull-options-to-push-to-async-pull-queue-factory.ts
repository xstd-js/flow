import { TimePushToAsyncPullQueueFactory } from '../built-in/buffer/buffer-push-to-async-pull-queue-factory/built-in/time-push-to-async-pull-queue-factory/time-push-to-async-pull-queue-factory.js';
import { EdgePushToAsyncPullQueueFactory } from '../built-in/edge/edge-push-to-async-pull-queue-factory/edge-push-to-async-pull-queue-factory.js';
import { type PushToAsyncPullQueueFactory } from '../push-to-async-pull-queue-factory.js';
import { type PushToPullOptions } from './push-to-pull-options.js';

export function pushToPullOptionsToPushToAsyncPullQueueFactory<GValue>(
  options: PushToPullOptions | undefined,
): PushToAsyncPullQueueFactory<GValue> {
  if (options === undefined || options.retentionTime === undefined || options.retentionTime <= 0) {
    return EdgePushToAsyncPullQueueFactory.edge<GValue>();
  } else {
    return new TimePushToAsyncPullQueueFactory<GValue>(options.retentionTime);
  }
}

export interface PushToPullOptions {
  readonly retentionTime?: number;
}

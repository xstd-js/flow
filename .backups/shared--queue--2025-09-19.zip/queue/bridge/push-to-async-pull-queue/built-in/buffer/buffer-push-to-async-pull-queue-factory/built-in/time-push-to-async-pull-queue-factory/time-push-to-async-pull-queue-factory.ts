import { NONE, type None } from '@xstd/none';
import { type QueueStep } from '../../../../../../../queue-step.js';
import {
  BufferPushToAsyncPullQueueFactory,
  type BufferPushToAsyncPullQueueFactoryOptions,
} from '../../buffer-push-to-async-pull-queue-factory.js';

interface Entry<GValue> {
  readonly step: QueueStep<GValue>;
  readonly expirationDate: number;
}

export class TimePushToAsyncPullQueueFactory<
  GValue,
> extends BufferPushToAsyncPullQueueFactory<GValue> {
  readonly #retentionTime: number;

  constructor(retentionTime: number) {
    if (retentionTime <= 0) {
      throw new Error('"retentionTime" must be greater to 0');
    }

    super((): BufferPushToAsyncPullQueueFactoryOptions<GValue> => {
      const queue: Entry<GValue>[] = [];

      return {
        push: (step: QueueStep<GValue>): void => {
          queue.push({
            step,
            expirationDate: Date.now() + this.#retentionTime,
          });
        },
        pull: (): QueueStep<GValue> | None => {
          const now: number = Date.now();
          while (queue.length > 0 && queue[0].expirationDate < now) {
            queue.shift();
          }

          if (queue.length === 0) {
            return NONE;
          } else {
            return queue.shift()!.step;
          }
        },
      };
    });

    this.#retentionTime = retentionTime;
  }
}

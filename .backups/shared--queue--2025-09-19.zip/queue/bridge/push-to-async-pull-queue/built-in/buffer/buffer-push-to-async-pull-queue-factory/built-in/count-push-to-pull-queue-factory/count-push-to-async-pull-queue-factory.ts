import { NONE, type None } from '@xstd/none';
import { type QueueStep } from '../../../../../../../queue-step.js';
import {
  BufferPushToAsyncPullQueueFactory,
  type BufferPushToAsyncPullQueueFactoryOptions,
} from '../../buffer-push-to-async-pull-queue-factory.js';

export class CountPushToAsyncPullQueueFactory<
  GValue,
> extends BufferPushToAsyncPullQueueFactory<GValue> {
  static #one: CountPushToAsyncPullQueueFactory<any>;

  static one<GValue = any>(): CountPushToAsyncPullQueueFactory<GValue> {
    if (this.#one === undefined) {
      this.#one = new CountPushToAsyncPullQueueFactory<GValue>(1);
    }
    return this.#one;
  }

  static #infinity: CountPushToAsyncPullQueueFactory<any>;

  static infinity<GValue = any>(): CountPushToAsyncPullQueueFactory<GValue> {
    if (this.#infinity === undefined) {
      this.#infinity = new CountPushToAsyncPullQueueFactory<GValue>(Number.POSITIVE_INFINITY);
    }
    return this.#infinity;
  }

  readonly #count: number;

  constructor(count: number) {
    if (count < 1) {
      throw new Error('Count must be greater or equal to 1');
    }

    super((): BufferPushToAsyncPullQueueFactoryOptions<GValue> => {
      const queue: QueueStep<GValue>[] = [];

      return {
        push: (step: QueueStep<GValue>): void => {
          queue.push(step);

          if (queue.length > this.#count) {
            queue.shift();
          }
        },
        pull: (): QueueStep<GValue> | None => {
          if (queue.length === 0) {
            return NONE;
          } else {
            return queue.shift()!;
          }
        },
      };
    });

    this.#count = count;
  }
}

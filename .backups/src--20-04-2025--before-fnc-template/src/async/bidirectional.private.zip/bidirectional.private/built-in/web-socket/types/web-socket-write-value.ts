export type WebSocketWriteValue = string | ArrayBufferLike | ArrayBufferView;

import { AsyncFlowFactory } from '../flow/factory/async-flow-factory.js';
import { type AsyncReadable } from '../read/readable/async-readable.js';
import { type AsyncWritable } from '../write/writable/async-writable.js';
import { BidirectionalAsyncFlow } from './bidirectional-async-flow.js';

export interface BidirectionalAsyncFlowFactoriesOptions<GRead, GWrite> {
  readonly readable: AsyncReadable<GRead>;
  readonly writable: AsyncWritable<GWrite>;
}

export interface BidirectionalAsyncFlowFactoriesMutateFunctionOptions<
  GRead,
  GWrite,
  GNewRead,
  GNewWrite,
> {
  (
    self: BidirectionalAsyncFlowFactories<GRead, GWrite>,
  ): BidirectionalAsyncFlowFactoriesOptions<GNewRead, GNewWrite>;
}

/**
 * @experimental
 */
export class BidirectionalAsyncFlowFactories<GRead, GWrite> {
  readonly #readable: AsyncReadable<GRead>;
  readonly #writable: AsyncWritable<GWrite>;

  constructor({ readable, writable }: BidirectionalAsyncFlowFactoriesOptions<GRead, GWrite>) {
    this.#readable = readable;
    this.#writable = writable;
  }

  get readable(): AsyncReadable<GRead> {
    return this.#readable;
  }

  get writable(): AsyncWritable<GWrite> {
    return this.#writable;
  }

  async open(signal?: AbortSignal): Promise<BidirectionalAsyncFlow<GRead, GWrite>> {
    const [reader, writer] = await AsyncFlowFactory.openMany<
      [AsyncReadable<GRead>, AsyncWritable<GWrite>]
    >([this.#readable, this.#writable], signal);

    return new BidirectionalAsyncFlow<GRead, GWrite>({
      reader,
      writer,
    });
  }

  mutate<GNewRead, GNewWrite>(
    mutateFnc: BidirectionalAsyncFlowFactoriesMutateFunctionOptions<
      GRead,
      GWrite,
      GNewRead,
      GNewWrite
    >,
  ): BidirectionalAsyncFlowFactories<GNewRead, GNewWrite> {
    const result: BidirectionalAsyncFlowFactoriesOptions<GNewRead, GNewWrite> = mutateFnc(this);

    if (result instanceof BidirectionalAsyncFlowFactories) {
      return result;
    } else {
      return new BidirectionalAsyncFlowFactories<GNewRead, GNewWrite>(result);
    }
  }
}

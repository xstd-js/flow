import { AsyncFlow } from '../flow/flow/async-flow.js';
import { type AsyncReader } from '../read/reader/async-reader.js';
import { type AsyncWriter } from '../write/writer/async-writer.js';

export interface BidirectionalAsyncFlowOptions<GRead, GWrite> {
  readonly reader: AsyncReader<GRead>;
  readonly writer: AsyncWriter<GWrite>;
}

/**
 * @experimental
 */
export class BidirectionalAsyncFlow<GRead, GWrite> {
  readonly #reader: AsyncReader<GRead>;
  readonly #writer: AsyncWriter<GWrite>;

  constructor({ reader, writer }: BidirectionalAsyncFlowOptions<GRead, GWrite>) {
    this.#reader = reader;
    this.#writer = writer;
  }

  get reader(): AsyncReader<GRead> {
    return this.#reader;
  }

  get writer(): AsyncWriter<GWrite> {
    return this.#writer;
  }

  close(reason?: unknown): Promise<void> {
    return AsyncFlow.closeMany([this.#reader, this.#writer], reason);
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}

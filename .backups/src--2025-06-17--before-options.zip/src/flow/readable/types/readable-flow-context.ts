import { FlowFactoryContext } from '../../flow/flow.js';

export type ReadableFlowContext = FlowFactoryContext<void, void>;
